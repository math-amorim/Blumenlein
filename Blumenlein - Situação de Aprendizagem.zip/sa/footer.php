<footer>
    The Wicked Logic™ by Matheus Amorim and Jean Meier<br><br>
    Fluent Concept™ 3.0 by Sant'Anna | Todos direitos reservados.
</footer>