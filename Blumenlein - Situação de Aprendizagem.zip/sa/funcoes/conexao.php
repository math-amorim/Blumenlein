<?php
   $conexao=mysqli_connect("localhost", "root", "","bd_sa_blumenlein") or 
   die (mysql_error('Erro na conexão'));
?>   