<?php 
 //opa
 //é a mesma logica do cadastro_endere_fornecedor
 //boa sorte
?>