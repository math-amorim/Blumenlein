var versao = document.querySelector("footer");
versao.innerHTML = "Fluent Concept™ 2.0 by Sant'Anna | Todos direitos reservados.";