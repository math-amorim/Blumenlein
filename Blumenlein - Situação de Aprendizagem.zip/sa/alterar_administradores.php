<?php 
    /*precisamos criar essa parte ainda. é a mesma lógica de alterar todos os outros. mas se não der não tem problema nenhum
    boa sorte man, jean*/
?>